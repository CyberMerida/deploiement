﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using ProjectoFinalQuiz.Models;

namespace ProjectoFinalQuiz.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuizExamenContext context;

        public HomeController(QuizExamenContext _context)
        {
            context = _context;
        }

        public IActionResult Index()
        {
            return View(context.Question);

        }

        public IActionResult NewQuiz()
        {

            return View();

        }
        [HttpPost]
        public IActionResult NewQuiz(string username, string email, int facile, int moyen, int dificile)
        {
            
            Quiz quiz = new Quiz();
            quiz.UserName = username;
            quiz.Email = email;

            context.Add<Quiz>(quiz);
            context.SaveChanges();

            int idQuiz = context.Quiz.OrderBy(quizN => quizN.QuizId).Last().QuizId;
            var questionFacile = context.Question.Where(q => q.CategoryId == 1).Take(facile).ToList();
            var questionMoyen = context.Question.Where(q => q.CategoryId == 2).Take(moyen).ToList();
            var questionDificil = context.Question.Where(q => q.CategoryId == 3).Take(dificile).ToList();

            foreach (var item in questionFacile)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();

                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
            }
            foreach (var item in questionMoyen)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();
                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
                //QuestionQuiz questionQ = new QuestionQuiz();
                //questionQ.
            }
            foreach (var item in questionDificil)
            {
                QuestionQuiz questionQuiz = new QuestionQuiz();
                questionQuiz.QuizId = idQuiz;
                questionQuiz.QuestionId = item.QuestionId;
                context.Add<QuestionQuiz>(questionQuiz);
                context.SaveChanges();
                //QuestionQuiz questionQ = new QuestionQuiz();
                //questionQ.
            }
            return RedirectToAction("Index");
         }
        public IActionResult PasseQuiz(string pattern)
          {
            if(pattern != null)
            {
                var quiz = context.Quiz.Where(c => c.UserName.StartsWith(pattern)).ToList();
                if (quiz.Count > 0)
                {
                    ViewBag.message = quiz.Count + "Trouver Quiz de " + pattern;
                    ViewBag.style = "text-succes";
                }
                else
                {
                    ViewBag.message = "Pas de result " + pattern;
                    ViewBag.style = "text-danger";
                }
                return View(quiz);
            }
            else 
        {
                {
                    return View();
                }
                return View();
            }
        }

        public IActionResult AnswersToQuiz(int id)
            {
                ViewBag.qzId = id;
                var QQ = context.QuestionQuiz.Where(q => q.QuizId == id);
                List<Question> listeQuest = new List<Question>();
                foreach (var item in QQ.ToList())
                {
                    var question = context.Question.Where(x => x.QuestionId == item.QuestionId).ToList();
                    listeQuest.Add(question[0]);
                }

                return View(listeQuest);

            }

        public IActionResult AnswrCorrectQuiz()
        {
            return View();

        }
        public IActionResult ReviewQuiz(string pattern)
        {
            if (pattern != null)
            {
                var quiz = context.Quiz.Where(c => c.UserName.StartsWith(pattern)).ToList();
                return View(quiz);
            }
            return View();

        }
        public IActionResult ReviewAnswersToQuiz(int id)
        {
           
                ViewBag.quizId = id;
                var quesQ = context.QuestionQuiz.Where(q => q.QuizId == id);
                List<Question> listeAnswer = new List<Question>();
                foreach (var item in quesQ.ToList())
                {
                    var question = context.Question.Where(x => x.QuestionId == item.QuestionId).ToList();

                    listeAnswer.Add(question[0]);
                }

                return View(listeAnswer);

            }
        public IActionResult Submit(int id)
        {

            foreach (var key in HttpContext.Request.Query.Keys)
            {
                Answer answer = new Answer();
                StringValues optionId;
                HttpContext.Request.Query.TryGetValue(key, out optionId);
                answer.OptionId = Int32.Parse(optionId);
                answer.QuizId = id;

                context.Add<Answer>(answer);
                context.SaveChanges();

            }

            return View("Index");

        }

    }

       }
    

